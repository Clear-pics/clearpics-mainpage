import React, { useState, useEffect, useRef } from 'react';
import {
  MessageSquare,
  X,
  Send,
  Sparkles,
  Bot,
  User,
  ShieldCheck,
  CalendarCheck,
  PhoneCall,
  Clock,
  ArrowRight,
  Maximize2,
  Minimize2,
  ChevronRight,
  RefreshCw
} from 'lucide-react';
import { DOCTORS } from '../data/doctors';
import { DISEASES } from '../data/diseases';
import { DiseaseId } from '../types';

interface Message {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  timestamp: string;
  actionType?: 'booking' | 'doctor' | 'insurance' | 'link';
  actionData?: {
    diseaseId?: DiseaseId;
    doctorId?: string;
    doctorName?: string;
    route?: string;
    title?: string;
  };
}

interface ChatBotProps {
  onOpenBooking: (diseaseId?: DiseaseId) => void;
  onNavigate: (route: string) => void;
}

const QUICK_TOPICS = [
  { label: '💳 Cashless Insurance & TPA', query: 'Does ClearPix accept my health insurance for cashless hospitalization?' },
  { label: '👨‍⚕️ Available Doctors Today', query: 'Which specialist doctors are available for consultation and surgeries?' },
  { label: '⏰ Daycare Surgery & Recovery', query: 'How soon can I walk home and return to work after daycare surgery?' },
  { label: '🩹 Piles Laser Treatment', query: 'Tell me about laser treatment for piles and sphincter preservation.' },
  { label: '🦵 Varicose Veins Laser vs Glue', query: 'What is the difference between EVLA laser and VenaSeal medical glue?' },
  { label: '💰 Consultation Fees & Second Opinion', query: 'What is the cost of consultation and can I bring past ultrasound reports for a second opinion?' },
  { label: '🪨 Kidney Stones Laser RIRS', query: 'How does no-cut laser RIRS work for kidney stones?' }
];

// Formats inline Markdown bold (**text**) and italics (*text*) cleanly without raw asterisks
const parseMarkdownText = (content: string, isUser: boolean = false) => {
  const parts = content.split(/(\*\*[^*]+\*\*|\*[^*]+\*)/g);
  return parts.map((part, index) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      const inner = part.slice(2, -2);
      return (
        <strong
          key={index}
          className={`font-semibold ${isUser ? 'text-white' : 'text-slate-900'}`}
        >
          {inner}
        </strong>
      );
    }
    if (part.startsWith('*') && part.endsWith('*') && part.length > 2) {
      return (
        <em key={index} className="italic text-slate-500">
          {part.slice(1, -1)}
        </em>
      );
    }
    return <React.Fragment key={index}>{part}</React.Fragment>;
  });
};

export const ChatBot: React.FC<ChatBotProps> = ({ onOpenBooking, onNavigate }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome-1',
      sender: 'bot',
      text: "Hello! I am **ClearPix Clinical Assistant**. I can help you with:\n\n• **100% Cashless Health Insurance & Pre-authorization**\n• **Doctor Availability & Direct Specialist Schedules**\n• **Laser & Daycare Surgery Recovery Timelines**\n• **Second Opinions & Preparation Guidelines**\n\nHow can I assist your health journey today?",
      timestamp: 'Just now'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen, isTyping]);

  // Intelligent clinical knowledge query matching
  const generateResponse = (rawQuery: string): { text: string; actionType?: Message['actionType']; actionData?: Message['actionData'] } => {
    const q = rawQuery.toLowerCase();

    // 1. Insurance & Cashless queries
    if (q.includes('insurance') || q.includes('cashless') || q.includes('tpa') || q.includes('mediclaim') || q.includes('coverage') || q.includes('claim')) {
      return {
        text: `### 100% Cashless Insurance at ClearPix 💳\n\n• **Accepted Insurers:** Star Health, BlueCross BlueShield, Aetna, Cigna, HDFC ERGO, United Healthcare, Care Health, Max Bupa, Bajaj Allianz, and all major corporate TPAs.\n• **Pre-Authorization Speed:** Under **60 minutes** paperless processing by our on-site TPA coordinators.\n• **Zero Out-of-Pocket Shock:** We provide complete transparent cost breakdowns prior to admission.\n• **Self-Pay Patients:** Flexible 0% interest EMI payment plans available.\n\nWould you like our insurance desk to pre-verify your policy eligibility?`,
        actionType: 'insurance',
        actionData: { title: 'Check Cashless Insurance with Coordinator' }
      };
    }

    // 2. Doctor Availability queries
    if (q.includes('doctor') || q.includes('specialist') || q.includes('surgeon') || q.includes('availability') || q.includes('who is') || q.includes('faculty') || q.includes('slot')) {
      return {
        text: `### ClearPix Senior Specialist Faculty 👨‍⚕️\n\nOur board-certified surgical leaders are currently accepting consultations:\n\n• **Dr. Aditi Sharma** (Endovascular & Vascular) — *Available Mon–Sat*\n• **Dr. Rajesh Nair** (Laser Proctology & Piles) — *Available Mon, Wed, Thu, Sat*\n• **Dr. Meera Venkatesh** (3D Laparoscopy & Hernia/Gallbladder) — *Available Tue, Wed, Fri, Sat*\n• **Dr. Siddharth Mehta** (Laser Urology & Kidney Stones) — *Available Mon, Tue, Thu, Fri*\n• **Dr. Kavita Menon** (Interventional Thyroid RFA) — *Available Mon, Wed, Fri, Sat*\n\nAll first evaluations include complimentary Doppler or preliminary ultrasound review. Which specialist would you like to consult?`,
        actionType: 'doctor',
        actionData: { title: 'View All Available Doctor Slots' }
      };
    }

    // 3. Piles / Hemorrhoids
    if (q.includes('pile') || q.includes('hemorrhoid') || q.includes('fissure') || q.includes('fistula') || q.includes('bleeding')) {
      return {
        text: `### Laser Hemorrhoidoplasty (LHP) for Piles 🩺\n\n• **Technique:** German 1470nm radial laser fiber applied to mucosal hemorrhoidal nodes with sub-millimeter precision.\n• **Zero Infiltration:** Intact anal sphincters preserved with 0% risk of incontinence or scarring.\n• **Pain Score:** Minimal post-op ache compared to painful open excision.\n• **Hospital Stay:** Daycare discharge in **4 to 6 hours**; resume normal desk work within 48 hours.\n\nWould you like to book an evaluation with **Dr. Rajesh Nair** (Proctology Lead)?`,
        actionType: 'booking',
        actionData: { diseaseId: 'piles', doctorId: 'dr-rajesh-nair', doctorName: 'Dr. Rajesh Nair' }
      };
    }

    // 4. Varicose Veins
    if (q.includes('vein') || q.includes('varicose') || q.includes('spider') || q.includes('leg pain') || q.includes('evla') || q.includes('venaseal')) {
      return {
        text: `### Varicose Veins Daycare Suite 🦵\n\n• **Endovenous Laser Ablation (EVLA):** Catheter-guided 1470nm laser gently collapses diseased saphenous veins with duplex Doppler navigation.\n• **VenaSeal Medical Glue:** Alternative no-thermal, no-tumescent medical adhesive procedure requiring zero compression stockings.\n• **Walking:** Patients walk immediately after the 30-minute procedure.\n• **Specialist:** Led by **Dr. Aditi Sharma** (Senior Endovascular Surgeon, 4,200+ procedures).\n\nYou can also take our self-assessment test on the site!`,
        actionType: 'booking',
        actionData: { diseaseId: 'varicose-veins', doctorId: 'dr-aditi-sharma', doctorName: 'Dr. Aditi Sharma' }
      };
    }

    // 5. Gallbladder Stones
    if (q.includes('gallbladder') || q.includes('gall') || q.includes('cholecyst') || q.includes('biliary')) {
      return {
        text: `### 3D Keyhole Laparoscopic Cholecystectomy 🫁\n\n• **Protocol:** Precision removal of stone-filled gallbladder via three 3–5mm pinhole incisions using 4K 3D laparoscopes.\n• **Why Not Medicines:** Medications cannot safely dissolve calcified cholesterol gallstones and risk acute pancreatitis or ductal blockage.\n• **Discharge:** Same-day or overnight observation (under 24 hours); back to walking within hours.\n• **Specialist:** **Dr. Meera Venkatesh** (Chief Laparoscopic & GI Surgeon, 3,800+ keyhole surgeries).`,
        actionType: 'booking',
        actionData: { diseaseId: 'gallbladder-stones', doctorId: 'dr-meera-venkatesh', doctorName: 'Dr. Meera Venkatesh' }
      };
    }

    // 6. Hernia
    if (q.includes('hernia') || q.includes('groin') || q.includes('bulge') || q.includes('mesh')) {
      return {
        text: `### 3D Keyhole Hernia Repair (TEP/TAPP) 🛡️\n\n• **Approach:** Anatomical 3D contoured lightweight mesh placement through micro-trocars without cutting abdominal wall muscles.\n• **Recurrence:** Under 1% compared to 10–15% in historical tensioned suture surgeries.\n• **Recovery:** Return to daily activities within 48 to 72 hours; gym/strenuous lifting resume in 3 weeks.\n• **Specialist:** **Dr. Meera Venkatesh** (Fellowship in Advanced Robotic & Laparoscopic Hernia Repair).`,
        actionType: 'booking',
        actionData: { diseaseId: 'hernia', doctorId: 'dr-meera-venkatesh', doctorName: 'Dr. Meera Venkatesh' }
      };
    }

    // 7. Kidney Stones
    if (q.includes('kidney') || q.includes('stone') || q.includes('rirs') || q.includes('ureter') || q.includes('renal')) {
      return {
        text: `### No-Cut Laser RIRS for Kidney Stones 🪨\n\n• **Retrograde Intrarenal Surgery (RIRS):** Flexible digital ureteroscope guided through natural urinary passages—zero skin cuts or puncture holes.\n• **Holmium Laser Dusting:** High-frequency laser pulses pulverize hard calculi into sub-millimeter fine dust that flushes out naturally.\n• **Stay:** Same-day discharge in 6 to 8 hours without painful abdominal drain tubes.\n• **Specialist:** **Dr. Siddharth Mehta** (Director of Laser Endourology, 6,100+ cases).`,
        actionType: 'booking',
        actionData: { diseaseId: 'kidney-stones', doctorId: 'dr-siddharth-mehta', doctorName: 'Dr. Siddharth Mehta' }
      };
    }

    // 8. Thyroid Nodules
    if (q.includes('thyroid') || q.includes('nodule') || q.includes('rfa') || q.includes('ablation') || q.includes('goiter') || q.includes('neck lump')) {
      return {
        text: `### Scarless Ultrasound-Guided Thyroid RFA 🦋\n\n• **Technique:** Targeted radiofrequency alternating current delivered via a hair-thin electrode needle directly inside benign nodules.\n• **Preserves Natural Thyroid:** Avoids surgical gland removal, meaning **no lifelong synthetic thyroid hormone pills**.\n• **Zero Neck Scar:** Pin-prick needle entry leaves zero visible stitches or surgical incision marks.\n• **Specialist:** **Dr. Kavita Menon** (Interventional Thyroid Radiologist, Seoul RFA Fellow).`,
        actionType: 'booking',
        actionData: { diseaseId: 'thyroid-ablation', doctorId: 'dr-kavita-menon', doctorName: 'Dr. Kavita Menon' }
      };
    }

    // 9. Cost / Pricing / Second Opinion
    if (q.includes('cost') || q.includes('price') || q.includes('fee') || q.includes('second opinion') || q.includes('report') || q.includes('free') || q.includes('charges')) {
      return {
        text: `### Consultation & Pricing Transparency 💡\n\n• **First Consultation:** Currently **$0 (Complimentary First Evaluation)** for all 6 specialties.\n• **Second Opinions:** You are strongly encouraged to bring any past CT, ultrasound, Doppler, or MRI scans. Our surgeons provide candid, unbiased second opinions on whether surgery is genuinely necessary.\n• **Full Cashless Package:** Covers pre-op diagnostic review, surgeon fees, operation theater, advanced laser fiber, and 30-day post-op follow-up care.`,
        actionType: 'booking',
        actionData: { title: 'Reserve Complimentary Consultation' }
      };
    }

    // 10. Recovery & Daycare queries
    if (q.includes('recover') || q.includes('walk') || q.includes('work') || q.includes('pain') || q.includes('leave') || q.includes('daycare') || q.includes('discharge')) {
      return {
        text: `### Daycare Surgery Recovery Timeline ⏰\n\n• **4 to 6 Hours Post-Op:** Walk out under your own steam with a companion.\n• **First 24 Hours:** Rest at home with light meals. No narcotics or heavy opioid pain relievers needed.\n• **Day 2 (48 Hours):** Resume desk work, light errands, and gentle walks.\n• **Dedicated Nurse Care:** 24/7 dedicated surgeon helpline and WhatsApp follow-up support.\n\nWould you like to schedule an assessment with our surgical team?`,
        actionType: 'booking',
        actionData: { title: 'Schedule Priority Slot' }
      };
    }

    // Generic helpful fallback
    return {
      text: `Thank you for your question. At ClearPix Healthcare, we specialize in minimally invasive day-care surgeries (Piles, Varicose Veins, Gallbladder, Hernia, Kidney Stones, and Thyroid Ablation).\n\n• **100% Cashless Insurance:** Accepted across all major providers with 60-minute pre-approval.\n• **Daycare Discharge:** Walk in and walk out the same day.\n• **Senior Faculty:** Direct access to fellowship-trained surgeons.\n\nWould you like to speak directly with our clinical care team or book a priority slot?`,
      actionType: 'booking',
      actionData: { title: 'Book Priority Consultation' }
    };
  };

  const handleSendMessage = (textToSend?: string) => {
    const query = textToSend || inputText;
    if (!query.trim()) return;

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: query.trim(),
      timestamp: 'Just now'
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    // Simulate natural clinical analysis typing delay
    setTimeout(() => {
      const response = generateResponse(query);
      const botMsg: Message = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: response.text,
        timestamp: 'Just now',
        actionType: response.actionType,
        actionData: response.actionData
      };
      setMessages(prev => [...prev, botMsg]);
      setIsTyping(false);
    }, 450);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <>
      {/* 1. FIXED FLOATING LAUNCHER BUTTON (Bottom-right corner) */}
      <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3">
        
        {/* Floating tooltip invitation (visible when closed) */}
        {!isOpen && (
          <button
            onClick={() => setIsOpen(true)}
            className="hidden sm:flex items-center gap-2 bg-white/95 backdrop-blur-md px-3.5 py-2 rounded-full border border-slate-200/90 shadow-lg text-xs font-semibold text-slate-800 hover:text-teal-700 hover:border-teal-500/40 transition-all cursor-pointer animate-in fade-in slide-in-from-right-4 duration-300"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Ask ClearPix AI · Insurance & Doctor Slots</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          </button>
        )}

        {/* Circular Action Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`w-14 h-14 rounded-full flex items-center justify-center text-white shadow-2xl transition-all duration-300 active:scale-95 cursor-pointer relative overflow-hidden border-2 border-white/90 ${
            isOpen
              ? 'bg-slate-900 rotate-90 hover:bg-slate-800'
              : 'hover:scale-105 hover:shadow-teal-900/40 p-0'
          }`}
          aria-label={isOpen ? 'Close clinical assistant' : 'Open clinical assistant'}
        >
          {isOpen ? (
            <X className="w-6 h-6" />
          ) : (
            <div className="relative w-full h-full flex items-center justify-center bg-slate-900">
              <img
                src="/images/chatbot_icon.jpg"
                alt="Chat Bot Icon"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover rounded-full"
              />
              {/* Online pulse indicator */}
              <span className="absolute top-0.5 right-0.5 w-3.5 h-3.5 bg-emerald-500 border-2 border-white rounded-full z-10 shadow-xs" />
            </div>
          )}
        </button>
      </div>

      {/* 2. SLIDE-OUT / POPUP CHATBOT WINDOW ASIDE */}
      {isOpen && (
        <div className="fixed bottom-24 right-4 sm:right-6 z-50 w-[calc(100vw-32px)] sm:w-[420px] h-[590px] max-h-[82vh] bg-white rounded-3xl shadow-2xl border border-slate-200/90 flex flex-col overflow-hidden animate-in slide-in-from-bottom-6 fade-in duration-300">
          
          {/* Header matching site's clean aesthetic */}
          <div className="px-5 py-4 bg-white text-slate-900 flex items-center justify-between border-b border-slate-200/90">
            <div className="flex items-center gap-3">
              <div className="relative w-9 h-9 rounded-xl overflow-hidden border border-slate-200/90 flex items-center justify-center shrink-0 bg-slate-50 shadow-2xs">
                <img
                  src="/images/chatbot_icon.jpg"
                  alt="ClearPix Chatbot"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 border border-white rounded-full" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="text-sm font-bold tracking-tight text-slate-950">ClearPix Assistant</h3>
                  <span className="text-[10px] bg-teal-50 text-teal-800 px-1.5 py-0.2 rounded border border-teal-200/80 font-mono font-medium">
                    24/7 AI
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 font-medium">
                  Insurance, Doctor Slots & Daycare Care
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => {
                  setMessages([
                    {
                      id: 'welcome-reset',
                      sender: 'bot',
                      text: "Chat cleared. How can I help you regarding our doctors, procedures, or health insurance coverage?",
                      timestamp: 'Just now'
                    }
                  ]);
                }}
                title="Restart conversation"
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                title="Close chat"
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick-Prompt Chips Carousel */}
          <div className="p-2.5 bg-slate-50 border-b border-slate-100 flex items-center gap-1.5 overflow-x-auto scrollbar-none text-[11px]">
            {QUICK_TOPICS.map((item, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(item.query)}
                className="px-2.5 py-1 rounded-full bg-white hover:bg-teal-50 text-slate-700 hover:text-teal-800 border border-slate-200 hover:border-teal-300 whitespace-nowrap shrink-0 transition-colors shadow-2xs font-medium cursor-pointer active:scale-95"
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Messages Scroll Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50/50">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[88%] p-3.5 rounded-2xl text-xs leading-relaxed shadow-2xs ${
                    msg.sender === 'user'
                      ? 'bg-slate-900 text-white rounded-br-xs'
                      : 'bg-white text-slate-800 border border-slate-200/90 rounded-bl-xs'
                  }`}
                >
                  {/* Message body with Markdown bold formatting parsed */}
                  <div className="space-y-2 text-xs leading-relaxed">
                    {msg.text.split('\n\n').map((para, i) => {
                      if (para.startsWith('### ')) {
                        const headingText = para.replace('### ', '');
                        return (
                          <div key={i} className="text-sm font-bold text-teal-950 pb-1 border-b border-slate-100 mb-1">
                            {parseMarkdownText(headingText, msg.sender === 'user')}
                          </div>
                        );
                      }

                      // Handle bullet points
                      if (para.includes('\n• ') || para.startsWith('• ')) {
                        const lines = para.split('\n');
                        return (
                          <div key={i} className="space-y-1 my-1">
                            {lines.map((line, lineIdx) => {
                              if (line.startsWith('• ')) {
                                return (
                                  <div key={lineIdx} className="flex items-start gap-1.5 pl-0.5">
                                    <span className="text-teal-600 font-bold shrink-0 mt-0.5">•</span>
                                    <span className="flex-1">
                                      {parseMarkdownText(line.slice(2), msg.sender === 'user')}
                                    </span>
                                  </div>
                                );
                              }
                              return (
                                <p key={lineIdx}>
                                  {parseMarkdownText(line, msg.sender === 'user')}
                                </p>
                              );
                            })}
                          </div>
                        );
                      }

                      return (
                        <p key={i}>
                          {parseMarkdownText(para, msg.sender === 'user')}
                        </p>
                      );
                    })}
                  </div>

                  {/* Embedded Interactive Action Card (if applicable) */}
                  {msg.actionType && (
                    <div className="mt-3 pt-3 border-t border-slate-100 space-y-2">
                      {msg.actionType === 'doctor' && (
                        <div className="grid grid-cols-1 gap-2">
                          {DOCTORS.slice(0, 3).map((d) => (
                            <div
                              key={d.id}
                              className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between gap-2"
                            >
                              <div className="truncate">
                                <span className="font-bold text-slate-900 block truncate">{d.name}</span>
                                <span className="text-[10px] text-teal-700 block truncate">{d.specialty}</span>
                              </div>
                              <button
                                onClick={() => {
                                  onOpenBooking(d.diseasesCovered[0]);
                                  setIsOpen(false);
                                }}
                                className="px-2.5 py-1 bg-slate-900 hover:bg-teal-700 text-white font-semibold text-[10px] rounded-lg shrink-0 transition-colors"
                              >
                                Book Slot
                              </button>
                            </div>
                          ))}
                        </div>
                      )}

                      {msg.actionType === 'booking' && (
                        <button
                          onClick={() => {
                            onOpenBooking(msg.actionData?.diseaseId);
                            setIsOpen(false);
                          }}
                          className="w-full py-2 px-3 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 shadow-sm transition-all active:scale-95 cursor-pointer"
                        >
                          <CalendarCheck className="w-3.5 h-3.5" />
                          <span>
                            {msg.actionData?.doctorName
                              ? `Schedule with ${msg.actionData.doctorName}`
                              : msg.actionData?.title || 'Book Priority Consultation'}
                          </span>
                        </button>
                      )}

                      {msg.actionType === 'insurance' && (
                        <div className="space-y-2">
                          <div className="p-2.5 bg-emerald-50/70 border border-emerald-200 rounded-xl text-[11px] text-emerald-900 flex items-center gap-2">
                            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                            <span>100% Cashless Pre-Auth with Star, BlueCross, Cigna, HDFC & All Major TPAs</span>
                          </div>
                          <button
                            onClick={() => {
                              onOpenBooking();
                              setIsOpen(false);
                            }}
                            className="w-full py-2 px-3 bg-slate-900 hover:bg-teal-700 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-sm"
                          >
                            <span>Verify Insurance Coverage</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <span className="text-[10px] text-slate-400 mt-1 px-1">
                  {msg.timestamp}
                </span>
              </div>
            ))}

            {/* Typing indicator */}
            {isTyping && (
              <div className="flex items-center gap-1.5 bg-white border border-slate-200 px-3.5 py-2.5 rounded-2xl rounded-bl-xs w-20 shadow-2xs">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-600 animate-bounce" />
                <span className="w-1.5 h-1.5 rounded-full bg-teal-600 animate-bounce [animation-delay:0.2s]" />
                <span className="w-1.5 h-1.5 rounded-full bg-teal-600 animate-bounce [animation-delay:0.4s]" />
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Footer Input */}
          <div className="p-3 bg-white border-t border-slate-200/90">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask about insurance, doctors, recovery..."
                className="flex-1 text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-600 transition-all text-slate-900 placeholder:text-slate-400"
              />
              <button
                onClick={() => handleSendMessage()}
                disabled={!inputText.trim()}
                className="p-2.5 rounded-xl bg-slate-900 hover:bg-teal-700 disabled:opacity-40 disabled:hover:bg-slate-900 text-white transition-colors cursor-pointer shrink-0 shadow-sm"
                aria-label="Send message"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
            
            <p className="text-[10px] text-center text-slate-400 mt-1.5">
              ClearPix Medical AI · For clinical emergencies, call 1800-CLEAR-PIX or 911
            </p>
          </div>

        </div>
      )}
    </>
  );
};
