import React from 'react';
import { ShieldCheck, HeartPulse, Sparkles, Building2, PhoneCall } from 'lucide-react';
import { DiseaseId } from '../types';

interface FooterProps {
  onNavigate: (path: string) => void;
  onOpenBooking: (diseaseId?: DiseaseId) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenBooking }) => {
  return (
    <footer className="bg-slate-100/80 text-slate-600 border-t border-slate-200">
      {/* Trust & Care Standards Bar */}
      <div className="border-b border-slate-200/90 bg-slate-50/70">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white border border-slate-200/90 flex items-center justify-center text-teal-700 shadow-2xs shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-900">USFDA-Approved Tech</p>
              <p className="text-xs text-slate-500">1470nm radial lasers & 4K 3D laparoscopes</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white border border-slate-200/90 flex items-center justify-center text-cyan-700 shadow-2xs shrink-0">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-900">NABH Accredited Theatres</p>
              <p className="text-xs text-slate-500">Ultra-sterile laminar airflow environments</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white border border-slate-200/90 flex items-center justify-center text-emerald-700 shadow-2xs shrink-0">
              <HeartPulse className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-900">Day-Care Discharge</p>
              <p className="text-xs text-slate-500">Walk home same day, resume life in 48 hours</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white border border-slate-200/90 flex items-center justify-center text-amber-700 shadow-2xs shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-900">100% Cashless Insurance</p>
              <p className="text-xs text-slate-500">Paperless approvals in under 60 minutes</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 grid grid-cols-1 md:grid-cols-5 gap-10">
        
        {/* Brand & Purpose */}
        <div className="md:col-span-2">
          <div className="flex items-center gap-2.5 mb-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-teal-700 to-cyan-600 flex items-center justify-center text-white font-bold text-sm shadow-2xs shrink-0">
              C
            </div>
            <div>
              <span className="text-lg font-bold text-slate-950 tracking-tight block leading-tight">ClearPix Healthcare</span>
              <span className="text-[11px] font-semibold text-teal-800 tracking-tight">Precision Surgery. Same-Day Freedom.</span>
            </div>
          </div>
          <p className="text-xs leading-relaxed text-slate-600 max-w-sm mb-6">
            ClearPix redefines elective and day-care surgery. By uniting premier surgical faculty with advanced laser and laparoscopic platforms, we deliver scarless, painless, stitch-free patient outcomes.
          </p>
          <div className="flex items-center gap-3 text-xs text-slate-600">
            <PhoneCall className="w-4 h-4 text-teal-700" />
            <span>Dedicated Patient Helpline:</span>
            <span className="font-semibold text-slate-900 tracking-wide">1800-CLEAR-PIX (Demo)</span>
          </div>
        </div>

        {/* Specialized Procedures */}
        <div>
          <p className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
            Specialized Care
          </p>
          <ul className="space-y-2.5 text-xs text-slate-600">
            <li>
              <button
                onClick={() => onNavigate('/piles')}
                className="hover:text-teal-800 transition-colors"
              >
                Piles (Laser Hemorrhoidoplasty)
              </button>
            </li>
            <li>
              <button
                onClick={() => onNavigate('/gallbladder-stones')}
                className="hover:text-teal-800 transition-colors"
              >
                Gallbladder (3D Laparoscopy)
              </button>
            </li>
            <li>
              <button
                onClick={() => onNavigate('/hernia')}
                className="hover:text-teal-800 transition-colors"
              >
                Hernia (3D Mesh Keyhole)
              </button>
            </li>
            <li>
              <button
                onClick={() => onNavigate('/thyroid-ablation')}
                className="hover:text-teal-800 transition-colors"
              >
                Thyroid (Scarless RFA Ablation)
              </button>
            </li>
            <li>
              <button
                onClick={() => onNavigate('/kidney-stones')}
                className="hover:text-teal-800 transition-colors"
              >
                Kidney Stones (No-Cut Laser RIRS)
              </button>
            </li>
            <li>
              <button
                onClick={() => onNavigate('/varicose-veins')}
                className="hover:text-teal-800 transition-colors"
              >
                Varicose Veins (Endovenous Laser EVLA)
              </button>
            </li>
          </ul>
        </div>

        {/* Patient Resources */}
        <div>
          <p className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
            Patient Support
          </p>
          <ul className="space-y-2.5 text-xs text-slate-600">
            <li>
              <button
                onClick={() => onOpenBooking()}
                className="hover:text-teal-800 transition-colors"
              >
                Book Surgical Consultation
              </button>
            </li>
            <li>
              <button
                onClick={() => {
                  onNavigate('/');
                  setTimeout(() => document.getElementById('core-focus')?.scrollIntoView({ behavior: 'smooth' }), 100);
                }}
                className="hover:text-teal-800 transition-colors"
              >
                Our Core Business Focus
              </button>
            </li>
            <li>
              <button
                onClick={() => {
                  onNavigate('/');
                  setTimeout(() => document.getElementById('patient-first')?.scrollIntoView({ behavior: 'smooth' }), 100);
                }}
                className="hover:text-teal-800 transition-colors"
              >
                The Patient Comes First
              </button>
            </li>
            <li>
              <button
                onClick={() => {
                  onNavigate('/');
                  setTimeout(() => document.getElementById('sustainable-business')?.scrollIntoView({ behavior: 'smooth' }), 100);
                }}
                className="hover:text-teal-800 transition-colors"
              >
                Sustainable Healthcare Business
              </button>
            </li>
          </ul>
        </div>

        {/* Clinical Advisory & Disclaimer */}
        <div>
          <p className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
            Clinical Transparency
          </p>
          <p className="text-xs leading-relaxed text-slate-500 mb-3">
            All procedures are conducted at NABH-accredited partner hospitals by certified super-specialists.
          </p>
          <div className="p-3 rounded-lg bg-white border border-slate-200 text-[11px] text-slate-600 shadow-2xs leading-normal">
            <span className="text-teal-800 font-semibold block mb-0.5">Emergency Notice:</span>
            If you are experiencing sudden severe chest pain, extreme breathlessness, or uncontrolled acute bleeding, call your local emergency service (911/112) immediately.
          </div>
        </div>

      </div>

      {/* Bottom Bar */}
      <div className="border-t border-slate-200/90 bg-slate-50/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span>© 2026 ClearPix Healthcare Technologies Inc.</span>
            <span>·</span>
            <span>All rights reserved</span>
            <span>·</span>
            <span className="text-slate-400">Demo Prototype</span>
          </div>
          <div className="flex items-center gap-6">
            <span className="hover:text-slate-800 transition-colors">Privacy Policy</span>
            <span className="hover:text-slate-800 transition-colors">Terms of Care</span>
            <span className="hover:text-slate-800 transition-colors">HIPAA Compliance</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
