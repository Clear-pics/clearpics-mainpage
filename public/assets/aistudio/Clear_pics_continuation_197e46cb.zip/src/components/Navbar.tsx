import React, { useState } from 'react';
import { Menu, X, ArrowUpRight } from 'lucide-react';
import { DiseaseId } from '../types';

interface NavbarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  onOpenBooking: (diseaseId?: DiseaseId) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPath,
  onNavigate,
  onOpenBooking
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { label: 'Piles', path: '/piles' },
    { label: 'Gallbladder', path: '/gallbladder-stones' },
    { label: 'Hernia', path: '/hernia' },
    { label: 'Thyroid', path: '/thyroid-ablation' },
    { label: 'Kidney', path: '/kidney-stones' },
    { label: 'Varicose Veins', path: '/varicose-veins' }
  ];

  const handleLinkClick = (path: string) => {
    onNavigate(path);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full glass-panel border-b border-slate-200/80 transition-all duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        
        {/* Zone 1: Single clean text element wordmark */}
        <button
          onClick={() => handleLinkClick('/')}
          className="group flex items-center gap-2 text-xl font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 hover:opacity-90 transition-opacity"
        >
          <span className="w-8 h-8 rounded-lg bg-gradient-to-tr from-teal-600 to-cyan-500 flex items-center justify-center text-white text-base font-extrabold shadow-sm">
            C
          </span>
          <span className="font-semibold tracking-tight">ClearPix</span>
        </button>

        {/* Zone 2: 4-6 concise single-line nav links with clean typography */}
        <nav className="hidden lg:flex items-center gap-5 text-xs font-medium text-slate-600">
          <button
            onClick={() => handleLinkClick('/')}
            className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
              currentPath === '/' ? 'text-teal-700 font-semibold border-b-2 border-teal-600' : 'hover:text-slate-900'
            }`}
          >
            Overview
          </button>
          {navItems.map((item) => {
            const isActive = currentPath === item.path;
            return (
              <button
                key={item.path}
                onClick={() => handleLinkClick(item.path)}
                className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
                  isActive ? 'text-teal-700 font-semibold border-b-2 border-teal-600' : 'hover:text-slate-900'
                }`}
              >
                {item.label}
              </button>
            );
          })}
          <button
            onClick={() => {
              if (currentPath !== '/') {
                handleLinkClick('/');
                setTimeout(() => document.getElementById('about-us')?.scrollIntoView({ behavior: 'smooth' }), 100);
              } else {
                document.getElementById('about-us')?.scrollIntoView({ behavior: 'smooth' });
              }
            }}
            className="whitespace-nowrap shrink-0 transition-colors py-1 hover:text-slate-900"
          >
            About
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onOpenBooking()}
            className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-full hover:bg-teal-700 active:scale-95 transition-all shadow-sm whitespace-nowrap shrink-0"
          >
            <span>Book Consultation</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>

          {/* Mobile hamburger toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-slate-700 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white/95 backdrop-blur-xl border-b border-slate-200 px-6 py-5 shadow-xl animate-in fade-in duration-200">
          <div className="flex flex-col gap-3">
            <button
              onClick={() => handleLinkClick('/')}
              className={`text-left py-2 text-sm font-medium transition-colors ${
                currentPath === '/' ? 'text-teal-700 font-semibold' : 'text-slate-700 hover:text-slate-900'
              }`}
            >
              Overview & All Conditions
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                if (currentPath !== '/') {
                  handleLinkClick('/');
                  setTimeout(() => document.getElementById('about-us')?.scrollIntoView({ behavior: 'smooth' }), 100);
                } else {
                  document.getElementById('about-us')?.scrollIntoView({ behavior: 'smooth' });
                }
              }}
              className="text-left py-2 text-sm font-medium text-slate-700 hover:text-slate-900"
            >
              About ClearPix
            </button>
            <div className="h-px bg-slate-100 my-1" />
            <div className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-1">
              Specialized Care Portals
            </div>
            {navItems.map((item) => (
              <button
                key={item.path}
                onClick={() => handleLinkClick(item.path)}
                className={`text-left py-2 text-sm font-medium flex items-center justify-between transition-colors ${
                  currentPath === item.path ? 'text-teal-700 font-semibold' : 'text-slate-700 hover:text-slate-900'
                }`}
              >
                <span>{item.label}</span>
                <span className="text-xs text-slate-400">View Clinic →</span>
              </button>
            ))}
            <div className="pt-3">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenBooking();
                }}
                className="w-full py-2.5 text-center text-sm font-semibold text-white bg-teal-600 rounded-lg hover:bg-teal-700 shadow-sm"
              >
                Book Priority Consultation
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
