import React from 'react';
import {
  ShieldCheck,
  ArrowRight,
  Building2
} from 'lucide-react';
import { DiseaseCard } from '../components/DiseaseCard';
import { DISEASES } from '../data/diseases';
import { DiseaseId } from '../types';

interface HomePageProps {
  onNavigate: (path: string) => void;
  onOpenBooking: (diseaseId?: DiseaseId) => void;
}

// Configurable image URLs - user can plug in direct image URLs here
export const ABOUT_US_IMAGE = '/images/about_us_facility.jpg';

export const HomePage: React.FC<HomePageProps> = ({ onNavigate, onOpenBooking }) => {
  const diseaseList = Object.values(DISEASES);

  return (
    <div className="space-y-24 pb-20">
      
      {/* Hero Section — Apple Inspired Pure Minimalist Typography */}
      <section className="relative pt-6 sm:pt-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        
        {/* Main Heading Area with Doctor Virtual Screen Background Image */}
        <div 
          className="relative rounded-3xl border border-slate-200/90 overflow-hidden shadow-lg py-20 sm:py-28 px-6 sm:px-12 text-center bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: "url('/images/hero_medical_bg.jpg')" }}
        >
          {/* Soft highlight layer ensuring vivid direct image presentation */}
          <div className="absolute inset-0 bg-white/20 pointer-events-none" />

          {/* Heading Content */}
          <div className="relative z-10 max-w-4xl mx-auto">
            {/* Unboxed Kicker */}
            <div className="inline-flex items-center justify-center gap-2 text-xs font-bold tracking-wider uppercase text-teal-900 bg-white/95 px-3.5 py-1.5 rounded-full shadow-2xs mb-5 border border-white/80">
              <span>Precision Minimally Invasive Healthcare</span>
              <span aria-hidden="true">·</span>
              <span>USFDA-Approved Protocols</span>
            </div>

            {/* Apple Display Headline with balanced wrap */}
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold text-slate-950 tracking-tight max-w-4xl mx-auto leading-[1.08] text-balance drop-shadow-sm">
              Surgical precision. <br className="hidden sm:inline" />
              <span className="text-teal-800 drop-shadow-sm">
                Zero compromise.
              </span>
            </h1>

            {/* Subhead Value Proposition */}
            <p className="mt-6 text-base sm:text-lg text-slate-900 font-medium max-w-2xl mx-auto leading-relaxed text-balance drop-shadow-xs">
              Next-generation laser, keyhole, and radiofrequency day-care surgery. 
              Stitch-free precision, minimal pain, and same-day discharge guided by world-class specialists.
            </p>

            {/* CTAs */}
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={() => onOpenBooking()}
                className="w-full sm:w-auto px-7 py-3.5 rounded-full text-xs font-semibold text-white bg-slate-950 hover:bg-teal-800 active:scale-95 transition-all shadow-md flex items-center justify-center gap-2"
              >
                <span>Schedule Specialist Consultation</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <a
                href="#conditions"
                className="w-full sm:w-auto px-7 py-3.5 rounded-full text-xs font-semibold text-slate-950 bg-white hover:bg-slate-100 border border-slate-300 transition-colors shadow-sm"
              >
                Explore 6 Specialty Portals
              </a>
            </div>
          </div>
        </div>

        {/* Unboxed Metadata Stats Strip */}
        <div className="mt-12 pt-4 max-w-4xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-6 text-center">
          <div>
            <div className="font-mono text-2xl sm:text-3xl font-bold text-slate-900 tabular-nums">
              50,000+
            </div>
            <div className="text-xs text-slate-500 mt-0.5">Successful Daycare Surgeries</div>
          </div>
          <div>
            <div className="font-mono text-2xl sm:text-3xl font-bold text-slate-900 tabular-nums">
              350+
            </div>
            <div className="text-xs text-slate-500 mt-0.5">Super-Specialist Faculty</div>
          </div>
          <div>
            <div className="font-mono text-2xl sm:text-3xl font-bold text-slate-900 tabular-nums">
              100%
            </div>
            <div className="text-xs text-slate-500 mt-0.5">Cashless Insurance Support</div>
          </div>
          <div>
            <div className="font-mono text-2xl sm:text-3xl font-bold text-teal-700 tabular-nums">
              4.96 / 5
            </div>
            <div className="text-xs text-slate-500 mt-0.5">Verified Patient Satisfaction</div>
          </div>
        </div>

      </section>

      {/* Six Clickable Disease Cards — Marquee Section */}
      <section id="conditions" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-24">
        
        {/* Section Header */}
        <div className="mb-10 text-center sm:text-left flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-teal-700 uppercase tracking-wider mb-1">
              <span>Dedicated Clinical Centers</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              Specialized Surgical Portals
            </h2>
            <p className="text-xs text-slate-500 mt-1 max-w-xl">
              Each condition operates as its own dedicated clinical portal within ClearPix, complete with diagnostic criteria, laser modalities, and specialist access.
            </p>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-xs text-slate-400">
            <span>6 Primary Procedures</span>
            <span>·</span>
            <span>All Day-Care Capable</span>
          </div>
        </div>

        {/* 6 Cards Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {diseaseList.map((disease) => (
            <DiseaseCard
              key={disease.id}
              disease={disease}
              onSelect={onNavigate}
              onQuickBook={onOpenBooking}
            />
          ))}
        </div>
      </section>

      {/* Clinical Superiority: Traditional vs ClearPix Minimally Invasive */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl border border-slate-200/90 p-8 sm:p-12 shadow-xs">
          
          <div className="max-w-2xl mb-10">
            <span className="text-xs font-semibold text-teal-700 uppercase tracking-wider block mb-1">
              The ClearPix Standard
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              Why minimally invasive laser care transforms your recovery.
            </h2>
            <p className="text-xs text-slate-500 mt-2">
              Compare conventional open surgeries against ClearPix German diode laser and 4K laparoscopic keyhole protocols.
            </p>
          </div>

          {/* Comparison Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                  <th className="py-3 pr-4">Clinical Parameter</th>
                  <th className="py-3 px-4 text-slate-500">Conventional Open Surgery</th>
                  <th className="py-3 pl-4 text-teal-700 font-bold bg-teal-50/50 rounded-t-xl">
                    ClearPix Precision Care
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                <tr>
                  <td className="py-3.5 pr-4 font-semibold text-slate-900">Hospital Stay</td>
                  <td className="py-3.5 px-4 text-slate-600">3 to 7 days hospital admission</td>
                  <td className="py-3.5 pl-4 font-semibold text-teal-800 bg-teal-50/50">
                    Daycare discharge (4-6 hours)
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 pr-4 font-semibold text-slate-900">Incision & Scars</td>
                  <td className="py-3.5 px-4 text-slate-600">8 to 15 cm open cuts with sutures</td>
                  <td className="py-3.5 pl-4 font-semibold text-teal-800 bg-teal-50/50">
                    Zero cuts (laser fiber) or 3-5mm pinholes
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 pr-4 font-semibold text-slate-900">Post-Op Discomfort</td>
                  <td className="py-3.5 px-4 text-slate-600">High pain score, requires injectable opioids</td>
                  <td className="py-3.5 pl-4 font-semibold text-teal-800 bg-teal-50/50">
                    Minimal soreness, mild oral pain relievers
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 pr-4 font-semibold text-slate-900">Normal Routine Resumption</td>
                  <td className="py-3.5 px-4 text-slate-600">3 to 5 weeks bed rest</td>
                  <td className="py-3.5 pl-4 font-semibold text-teal-800 bg-teal-50/50">
                    24 to 48 hours back to desk work
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 pr-4 font-semibold text-slate-900">Sphincter & Tissue Trauma</td>
                  <td className="py-3.5 px-4 text-slate-600">Risk of structural muscle scarring</td>
                  <td className="py-3.5 pl-4 font-semibold text-teal-800 bg-teal-50/50">
                    100% sphincter & tissue preservation
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 pr-4 font-semibold text-slate-900">Clinical Recurrence Rate</td>
                  <td className="py-3.5 px-4 text-slate-600">10% – 16% historical average</td>
                  <td className="py-3.5 pl-4 font-semibold text-teal-800 bg-teal-50/50 rounded-b-xl">
                    &lt; 2.1% across 5-year registries
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

        </div>
      </section>

      {/* NEW SECTION 1: ABOUT US */}
      <section id="about-us" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-24">
        <div className="bg-white rounded-3xl border border-slate-200/90 p-8 sm:p-14 shadow-xs">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Narrative (7 Cols) */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-teal-800 bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
                <Building2 className="w-3.5 h-3.5 text-teal-700" />
                <span>About ClearPix Healthcare</span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight text-balance">
                Pioneering the era of scarless, zero-stitch surgical daycare.
              </h2>

              <p className="text-sm sm:text-base text-slate-600 leading-relaxed font-normal">
                Founded by senior vascular, laparoscopic, and laser surgeons, ClearPix was built on a singular conviction: elective surgery should never mean weeks of painful bed confinement or disfiguring scars.
              </p>

              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                By replacing traditional open scalpel incisions with 1470nm radial laser fibers, 4K 3D keyhole laparoscopy, and ultrasound-guided radiofrequency ablation, we resolve complex conditions within 30 to 45 minutes—allowing patients to walk home the very same afternoon.
              </p>

              {/* 3 Core Pillars */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-3 border-t border-slate-100">
                <div className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200/70 space-y-1.5">
                  <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-xs">
                    01
                  </div>
                  <h4 className="text-xs font-bold text-slate-900">Sub-Millimeter Tech</h4>
                  <p className="text-[11px] text-slate-500 leading-snug">
                    German diode lasers & 4K laparoscopes ensuring zero healthy tissue trauma.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200/70 space-y-1.5">
                  <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-xs">
                    02
                  </div>
                  <h4 className="text-xs font-bold text-slate-900">Outpatient Daycare</h4>
                  <p className="text-[11px] text-slate-500 leading-snug">
                    Walk in for surgery and return home within 4 to 6 hours with 24/7 care.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200/70 space-y-1.5">
                  <div className="w-8 h-8 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold text-xs">
                    03
                  </div>
                  <h4 className="text-xs font-bold text-slate-900">100% Cashless TPA</h4>
                  <p className="text-[11px] text-slate-500 leading-snug">
                    Zero upfront surprise costs with immediate pre-authorization desk.
                  </p>
                </div>
              </div>
            </div>

            {/* Right: PLACE TO ADD ABOUT US IMAGE WITH HOVER EFFECT (5 Cols) */}
            <div className="lg:col-span-5 flex flex-col items-center">
              <div className="relative w-full aspect-[4/3] rounded-3xl overflow-hidden border border-slate-200/90 shadow-md group cursor-pointer bg-slate-900 transition-all duration-500 hover:shadow-2xl hover:border-teal-400/60 hover:-translate-y-1">
                
                {/* Image slot */}
                {ABOUT_US_IMAGE ? (
                  <img
                    src={ABOUT_US_IMAGE}
                    alt="About ClearPix Advanced Surgical Center"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                  />
                ) : (
                  /* High-Fidelity Architectural Cleanroom OT Presentation (Ready for User's image link) */
                  <div className="relative w-full h-full bg-gradient-to-tr from-slate-950 via-slate-900 to-teal-950 flex flex-col justify-between p-6 overflow-hidden">
                    {/* Background architectural grid graphic */}
                    <svg className="absolute inset-0 w-full h-full opacity-20 pointer-events-none transition-transform duration-700 group-hover:scale-110" viewBox="0 0 400 300" fill="none">
                      <path d="M0 50 H400 M0 100 H400 M0 150 H400 M0 200 H400 M0 250 H400" stroke="#0D9488" strokeWidth="0.5" strokeDasharray="4 4" />
                      <path d="M50 0 V300 M100 0 V300 M150 0 V300 M200 0 V300 M250 0 V300 M300 0 V300 M350 0 V300" stroke="#0D9488" strokeWidth="0.5" strokeDasharray="4 4" />
                      <circle cx="200" cy="150" r="80" stroke="#14B8A6" strokeWidth="1" opacity="0.6" />
                      <circle cx="200" cy="150" r="110" stroke="#14B8A6" strokeWidth="0.5" strokeDasharray="6 6" opacity="0.4" />
                    </svg>

                    {/* Top status indicator with hover glow */}
                    <div className="relative z-10 flex items-center justify-between">
                      <div className="flex items-center gap-2 bg-slate-950/80 backdrop-blur-md px-3 py-1.5 rounded-full border border-teal-500/30 text-[10px] font-mono text-teal-300">
                        <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse" />
                        <span>NABH ULTRA-STERILE SUITE</span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono">FACILITY #01</span>
                    </div>

                    {/* Center holographic icon graphic */}
                    <div className="relative z-10 text-center space-y-2 my-auto">
                      <div className="w-16 h-16 rounded-2xl bg-teal-500/10 border border-teal-400/30 text-teal-300 flex items-center justify-center mx-auto transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3 shadow-lg shadow-teal-500/10">
                        <Building2 className="w-8 h-8 text-teal-300" />
                      </div>
                      <p className="text-xs font-bold text-white tracking-wide">
                        ClearPix Surgical Center of Excellence
                      </p>
                      <p className="text-[11px] text-teal-200/80 max-w-xs mx-auto">
                        Image Slot: Ready for your Facility Photo
                      </p>
                    </div>

                    {/* Bottom floating badge with hover slide animation */}
                    <div className="relative z-10 flex items-center justify-between pt-2 border-t border-slate-800/80 text-[11px] text-slate-300">
                      <span>Laminar Airflow Cleanroom</span>
                      <span className="text-teal-400 font-semibold group-hover:translate-x-1 transition-transform">
                        Hover to Preview →
                      </span>
                    </div>
                  </div>
                )}

                {/* Scrim Overlay & Hover Glaze */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity pointer-events-none" />

                {/* Floating Bottom Pill Badge with Hover Motion */}
                <div className="absolute bottom-4 left-4 right-4 z-20 flex items-center justify-between pointer-events-none">
                  <div className="bg-slate-950/90 backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-slate-700/80 text-white text-xs font-semibold flex items-center gap-2 shadow-lg transition-transform duration-300 group-hover:-translate-y-1">
                    <ShieldCheck className="w-4 h-4 text-teal-400" />
                    <span>NABH Certified Partner Pavilion</span>
                  </div>
                  <span className="text-[10px] text-teal-300 font-medium bg-teal-950/80 px-2 py-1 rounded-lg border border-teal-500/30">
                    Day-Care
                  </span>
                </div>
              </div>

              <p className="text-center text-[11px] text-slate-400 mt-3">
                * You can provide your facility image link anytime to replace this placeholder.
              </p>
            </div>

          </div>
        </div>
      </section>

      {/* Patient Care Pathway */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-semibold text-teal-700 uppercase tracking-wider block mb-1">
            Seamless Patient Experience
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            From initial consultation to complete recovery.
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Your dedicated ClearPix Care Coordinator handles hospital booking, insurance pre-authorization, and post-operative follow-ups.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[
            {
              step: '01',
              title: 'Expert Consultation',
              desc: 'Meet your dedicated senior super-specialist for physical exam and high-resolution duplex Doppler or ultrasound scan.'
            },
            {
              step: '02',
              title: 'Instant Cashless Insurance',
              desc: 'Our dedicated TPA team completes 100% cashless pre-authorization with your health insurer in under 60 minutes.'
            },
            {
              step: '03',
              title: '30-Minute Laser Procedure',
              desc: 'Undergo precision laser or laparoscopic surgery in an ultra-sterile NABH laminar airflow suite under gentle sedation.'
            },
            {
              step: '04',
              title: 'Same-Day Discharge',
              desc: 'Rest in private suite and walk out comfortably within 4 to 6 hours with 24/7 dedicated surgeon chat support.'
            }
          ].map((item) => (
            <div
              key={item.step}
              className="p-6 rounded-2xl bg-white border border-slate-200/90 shadow-2xs space-y-3 relative"
            >
              <div className="font-mono text-xs font-bold text-teal-700">
                {item.step}.
              </div>
              <h3 className="text-sm font-bold text-slate-900">{item.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>



      {/* Marquee Consultation Callout Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-slate-100 via-slate-50 to-teal-50/50 rounded-3xl border border-slate-200/90 p-8 sm:p-14 text-slate-900 flex flex-col lg:flex-row items-center justify-between gap-8 shadow-xs">
          <div className="space-y-3 max-w-xl text-center lg:text-left">
            <span className="text-xs font-semibold text-teal-800 uppercase tracking-wider block">
              Direct Access to Top Surgeons
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-slate-950">
              Ready for a scarless, pain-free recovery?
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Schedule your confidential consultation today. Get clear surgical guidance, ultrasound diagnostic evaluation, and 100% cashless insurance verification.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 shrink-0 w-full sm:w-auto">
            <button
              onClick={() => onOpenBooking()}
              className="py-3.5 px-8 rounded-full text-xs font-semibold text-white bg-slate-900 hover:bg-teal-700 active:scale-95 transition-all shadow-md text-center"
            >
              Book Priority Consultation
            </button>
          </div>
        </div>
      </section>

    </div>
  );
};
